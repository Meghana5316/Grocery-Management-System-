package com.cjits.service;


import com.cjits.entity.Bill;

import java.util.List;

    public interface BillService {
        Bill createBill(Bill bill);

//        Bill getBillById(int billId);

        List<Bill> getAllBills();

        void deleteBill(Long id);

        Bill getBillById(Long id);

        Bill updateBill(Long id, Bill bill);

        double calculateTotalAmount(Bill bill);
    }

