package com.cjits.service;


import com.cjits.entity.Bill;
import com.cjits.repository.BillRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

    @Service
    public class BillServiceImpl implements BillService {

        @Autowired
        private BillRepository billRepository;

        @Override
        @Transactional
        public Bill createBill(Bill bill) {
            double totalAmount = calculateTotalAmount(bill);
            bill.setTotalAmount(totalAmount);
            return billRepository.save(bill);
        }

//        @Override
//        public Bill getBillById(int billId) {
//            return null;
//        }

        @Override
        public List<Bill> getAllBills() {

            return billRepository.findAll();
        }

        @Override
        public Bill getBillById(Long id) {
            Optional<Bill> billOptional = billRepository.findById(id);
            // Check if the Optional contains a value
            if (billOptional.isPresent()) {
                // Return the Bill if it exists
                return billOptional.get();
            } else {
                // Throw an exception indicating that the Bill with the specified ID was not found
                throw new IllegalArgumentException("Bill not found for id: " + id);
            }
        }


//        @Override
//        public Bill getBillById(Long id) {
//            Optional<Bill> billOptional = billRepository.findById(id);
//            return billOptional.orElse(null);
//        }

        @Override
        public Bill updateBill(Long id, Bill bill) {
            if (billRepository.existsById(id)) {
                bill.setId(id);
                bill.setTotalAmount(calculateTotalAmount(bill));
                return billRepository.save(bill);
            }
            return null;
        }

        @Override
        public void deleteBill(Long id) {
            billRepository.deleteById(id);
        }

        @Override
        public double calculateTotalAmount(Bill bill) {
            // Implement the logic to calculate total amount
            // For example, sum of amount and any additional charges
            return bill.getAmount(); // For now, returning the same amount as total

        }
    }

