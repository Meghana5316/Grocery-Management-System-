package com.cjits.controller;


import com.cjits.entity.Bill;
import com.cjits.service.BillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

    @RestController
    @RequestMapping("/api/bills")
    public class BillController {

        @Autowired
        private BillService billService;
        @PostMapping
        public Bill createBill(@RequestBody Bill bill) {
            return billService.createBill(bill);
        }
        @GetMapping
        public List<Bill> getAllBills() {
            return billService.getAllBills();
        }

        // Get a bill by ID
//        @GetMapping("/{id}")
//        public Bill getBillById(@PathVariable long id) {
//            return billService.getBillById(id);
//        }

        @GetMapping("/bills/{id}")
        public ResponseEntity<Bill> getBillById(@PathVariable Long id) {
            Bill bill = billService.getBillById(id);
            if (bill != null) {
                return ResponseEntity.ok(bill);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }
        }
        // Update a bill by ID
        @PutMapping("/{id}")
        public Bill updateBill(@PathVariable Long id, @RequestBody Bill bill) {
            return billService.updateBill(id, bill);
        }

        // Delete a bill by ID
        @DeleteMapping("/{id}")
        public void deleteBill(@PathVariable Long id) {
            billService.deleteBill(id);
        }

        // Get total amount of a bill by ID
        @GetMapping("/{id}/total")
        public double getTotalAmount(@PathVariable long id) {
            Bill bill = billService.getBillById(id);
            if (bill != null) {
                return billService.calculateTotalAmount(bill);
            }
            return 0.0; // Return 0 if bill is not found
        }
    }

