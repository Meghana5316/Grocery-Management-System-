package com.cjits.entity;


import jakarta.persistence.*;

import java.util.List;
import java.util.Optional;

@Entity
    public class Bill {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;
        @OneToMany(cascade = CascadeType.ALL)
        private List<Product> products;

        private double totalAmount;



        // Getters and setters

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public List<Product> getProducts() {
            return products;
        }

        public void setProducts(List<Product> products) {
            this.products = products;
        }

        public double getTotalAmount() {
            return totalAmount;
        }

        public void setTotalAmount(double totalAmount) {
            this.totalAmount = totalAmount;
        }

        public double getAmount() {
            return totalAmount;
        }

        public Optional<Object> getItems() {
            return null;
        }
    }

