package com.cjits.service;

import com.cjits.entity.ProductType;
import com.cjits.repository.ProductTypeRepository;
import com.cjits.service.ProductTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class ProductTypeServiceImpl implements ProductTypeService {

    @Autowired
    private ProductTypeRepository productTypeRepository;

    @Override
    public List<ProductType> getAllProductTypes() {
        return productTypeRepository.findAll();
    }

    @Override
    public ProductType getProductTypeByName(String name) {
        return productTypeRepository.findByName(name);
    }


    @Override
    public ProductType getProductTypeById(Long id) {
        return productTypeRepository.findById(id).orElse(null);
    }

    @Override
    public ProductType addProductType(ProductType productType) {
        return productTypeRepository.save(productType);
    }

    @Override
    public ProductType updateProductType(Long id, ProductType productType) {
        ProductType existingProductType = getProductTypeById(id);
        if (existingProductType != null) {
            productType.setId(id);
            return productTypeRepository.save(productType);
        }
        return null;
    }

    @Override
    public void deleteProductType(Long id) {
        productTypeRepository.deleteById(id);
    }
}
