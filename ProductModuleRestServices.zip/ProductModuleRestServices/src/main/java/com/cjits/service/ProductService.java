package com.cjits.service;

import com.cjits.entity.Product;

import java.util.List;

public interface ProductService {

    List<Product> getAllProducts();
    Product getProductById(Long id);
    Product getProductByName(String name);
    Product addProduct(Product product);
    Product updateProduct(Long id, Product product);
    void deleteProduct(Long id);
    List<Product> getProductsByProductTypeId(Long productTypeId);
    Product getProductByProductTypeName(String productTypeName);
}
