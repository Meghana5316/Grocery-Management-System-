package com.cjits.service;

import com.cjits.entity.ProductType;

import java.util.List;

public interface ProductTypeService {

    List<ProductType> getAllProductTypes();
    ProductType getProductTypeById(Long id);
    ProductType getProductTypeByName(String name);
    ProductType addProductType(ProductType productType);
    ProductType updateProductType(Long id, ProductType productType);
    void deleteProductType(Long id);
}

