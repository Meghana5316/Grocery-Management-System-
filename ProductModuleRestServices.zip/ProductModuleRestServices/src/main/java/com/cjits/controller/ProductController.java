package com.cjits.controller;
import com.cjits.entity.Product;
import com.cjits.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    @GetMapping("/{id}")
    public Product getProductById(@PathVariable Long id) {
        return productService.getProductById(id);
    }
    @GetMapping("/name/{name}")
    public Product getProductByName(@PathVariable String name) {
        return productService.getProductByName(name);
    }

    @PostMapping
    public Product addProduct(@RequestBody Product product) {
        return productService.addProduct(product);
    }

    @PutMapping("/{id}")
    public Product updateProduct(@PathVariable Long id, @RequestBody Product product) {
        return productService.updateProduct(id, product);
    }

    @DeleteMapping("/{id}")
    public void deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
    }

    @GetMapping("/byProductType/{productTypeId}")
    public List<Product> getProductsByProductTypeId(@PathVariable Long productTypeId) {
        return productService.getProductsByProductTypeId(productTypeId);
    }
    @GetMapping("/products/type/{productTypeName}")
    public Product getProductByProductTypeName(@PathVariable String productTypeName) {
        return productService.getProductByProductTypeName(productTypeName);
    }
}

