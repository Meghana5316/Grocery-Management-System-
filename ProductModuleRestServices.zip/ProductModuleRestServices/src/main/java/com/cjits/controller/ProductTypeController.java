

package com.cjits.controller;
import com.cjits.entity.ProductType;
import com.cjits.service.ProductTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/product-types")
public class ProductTypeController {

    @Autowired
    private ProductTypeService productTypeService;

    @GetMapping
    public List<ProductType> getAllProductTypes() {
        return productTypeService.getAllProductTypes();
    }

    @GetMapping("/{id}")
    public ProductType getProductTypeById(@PathVariable Long id) {
        return productTypeService.getProductTypeById(id);
    }
    @GetMapping("/name/{name}")
    public ProductType getProductTypeByName(@PathVariable String name) {
        return productTypeService.getProductTypeByName(name);
    }

    @PostMapping
    public ProductType addProductType(@RequestBody ProductType productType) {
        return productTypeService.addProductType(productType);
    }

    @PutMapping("/{id}")
    public ProductType updateProductType(@PathVariable Long id, @RequestBody ProductType productType) {
        return productTypeService.updateProductType(id, productType);
    }

    @DeleteMapping("/{id}")
    public void deleteProductType(@PathVariable Long id) {
        productTypeService.deleteProductType(id);
    }
}
