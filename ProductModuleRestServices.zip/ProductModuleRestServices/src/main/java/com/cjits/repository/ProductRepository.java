package com.cjits.repository;

import com.cjits.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {
    Product findByName(String name);

    List<Product> findByProductTypeId(Long productTypeId);

    Product findByProductType_Name(String productTypeName);

}


